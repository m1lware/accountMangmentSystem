This is Java program that have Menu about Account Managment System, it is encrypt the password and it is saves it into text file :)
